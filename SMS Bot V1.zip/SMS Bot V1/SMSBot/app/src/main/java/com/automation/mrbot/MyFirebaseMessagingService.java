package com.automation.mrbot;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "MyFirebaseMsgService";


    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // TODO(developer): Handle FCM messages here.

        String action = remoteMessage.getData().get("action");
        String number = remoteMessage.getData().get("number");
        String body = remoteMessage.getData().get("body");

        if (action!=null && action.contains("send_sms_now")){
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(number, null, body, null, null );
        }


    }

    ////============================================================
    ////============================================================

    ////============================================================




    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        //Send this token to your server
        Log.d("firebaseToken", token);

    }

    //================================================



}

