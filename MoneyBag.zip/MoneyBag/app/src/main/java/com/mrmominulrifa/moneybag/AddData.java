package com.mrmominulrifa.moneybag;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddData extends AppCompatActivity {
    TextView tvTitle;

    EditText edAmount, edReason;
    Button btnaddExpense;

    DatabaseHelper dbHelper;

    public static boolean EXPANSE = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        tvTitle = findViewById(R.id.tvTitle);
        edAmount = findViewById(R.id.edamount);
        edReason = findViewById(R.id.edreason);
        btnaddExpense = findViewById(R.id.buttondd);
        dbHelper = new DatabaseHelper(AddData.this);


        if (EXPANSE==true) {
            tvTitle.setText("Add Expense");
        }else {
            tvTitle.setText("Add Income ");
            btnaddExpense.setText("Add Income");
        }


        btnaddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String sAmount = edAmount.getText().toString();
                String reason = edReason.getText().toString();
                double amount = Double.parseDouble(sAmount);

                if (EXPANSE==true){
                    dbHelper.addExpense(amount, reason);
                    tvTitle.setText("Expense Amount Added...!!");

                }else {
                    dbHelper.addIncome(amount, reason);
                    tvTitle.setText("Income Amount Added...!!");

                }
            }
        });


    }  ///////-------------------------------


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}