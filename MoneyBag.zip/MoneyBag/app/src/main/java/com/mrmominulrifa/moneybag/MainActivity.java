package com.mrmominulrifa.moneybag;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvFianlBal ,totalExpense  , addExpense  , showALLDataExpense , totalIncome  , addIncome , showallDataIncome ;

    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvFianlBal = findViewById(R.id.tvFinalBal);
        totalExpense = findViewById(R.id.tvTotalExpense);
        addExpense = findViewById(R.id.tvAddExpense);
        showALLDataExpense = findViewById(R.id.tvShowALLdataExpense);
        totalIncome = findViewById(R.id.totalIncome);
        addIncome = findViewById(R.id.tvAddIncome);
        showallDataIncome = findViewById(R.id.tvShowAllDataIncome);
        dbHelper = new DatabaseHelper(MainActivity.this);

        addExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddData.EXPANSE = true;
                startActivity(new Intent(MainActivity.this, AddData.class));
            }
        });

        addIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddData.EXPANSE = false;
                startActivity(new Intent(MainActivity.this, AddData.class));
            }
        });

        showALLDataExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowData.EXPANSE = true;
                startActivity(new Intent(MainActivity.this, ShowData.class));
            }
        });

        showallDataIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowData.EXPANSE = false;
                startActivity(new Intent(MainActivity.this, ShowData.class));
            }
        });



        updateUI();

    }///----------------

    public void updateUI(){
        totalExpense.setText("BDT " + dbHelper.calculateTotalExpense());
        totalIncome.setText("BDT " + dbHelper.calculateTotalIncome());

        double balance = dbHelper.calculateTotalIncome() - dbHelper.calculateTotalExpense();
        tvFianlBal.setText("BDT " + balance);
    }


    @Override
    protected void onPostResume() {
        super.onPostResume();
        updateUI();
    }
}