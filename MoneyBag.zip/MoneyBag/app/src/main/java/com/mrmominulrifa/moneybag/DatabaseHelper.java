package com.mrmominulrifa.moneybag;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "digital_Moneybag";
    public static final int DB_VERSION = 1 ;
    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table expense_table (id INTEGER primary key autoincrement , amount DOUBLE, reason TEXT, time DOUBLE) " );
        db.execSQL("create table income_table (id INTEGER primary key autoincrement , amount DOUBLE, reason TEXT, time DOUBLE) " );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists expense_table");
        db.execSQL("drop table if exists income_table");
    }

    //-------------------------------------------------------------------------
    public void addExpense(double amount, String reason ){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues conval = new ContentValues();
        conval.put("amount", amount);
        conval.put("reason",reason);
        conval.put("time",System.currentTimeMillis() );
        database.insert("expense_table" , null, conval);
    }
    //-------------------------------------------------------------------------

    public double calculateTotalExpense(){

        double totalExpense = 0;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from expense_table " , null);

        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                double amount = cursor.getDouble(1);
                totalExpense = totalExpense + amount;
            }
        }
        return totalExpense;
    }

    //-------------------------------------------------------------------------

    public void addIncome(double amount, String reason ){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues conval = new ContentValues();
        conval.put("amount", amount);
        conval.put("reason",reason);
        conval.put("time",System.currentTimeMillis() );
        database.insert("income_table" , null, conval);
    }
    //-------------------------------------------------------------------------


    public double calculateTotalIncome(){

        double totalIncome = 0;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from income_table " , null);

        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                double amount = cursor.getDouble(1);
                totalIncome = totalIncome + amount;
            }
        }
        return totalIncome;
    }

    //-------------------------------------------------------------------------

    public Cursor getAllExpanses(){

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from expense_table", null);
        return cursor;
    }
    //-------------------------------------------------------------------------
    public Cursor getAllIncome(){

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from income_table", null);
        return cursor;
    }
    //-------------------------------------------------------------------------

    public void deletebyExpense(String id){

        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL("delete from expense_table where id like " + id);
    }
    //-------------------------------------------------------------------------

    public void deletebyIncome(String id){

        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL("delete from income_table where id like " + id);
    }
    //-------------------------------------------------------------------------




}
