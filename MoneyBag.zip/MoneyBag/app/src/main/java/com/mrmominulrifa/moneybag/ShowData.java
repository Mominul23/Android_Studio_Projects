package com.mrmominulrifa.moneybag;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class ShowData extends AppCompatActivity {

    TextView tvTitle;
    ListView listView;
    DatabaseHelper dbHelper;
    ArrayList<HashMap<String, String>> arrayList;
    HashMap<String, String> hashMap;
    public static boolean EXPANSE = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);


        tvTitle = findViewById(R.id.tvTitle);
        listView = findViewById(R.id.listview);
        dbHelper = new DatabaseHelper(ShowData.this);


        if (EXPANSE==true) {
            tvTitle.setText("Expense History");
        }else {
            tvTitle.setText("Income History");
        }



        loadData();

    }///---------------------------


    public void loadData(){

        Cursor cursor = null;

        if (EXPANSE==true) cursor = dbHelper.getAllExpanses();
        else cursor = dbHelper.getAllIncome();

        if (cursor!=null && cursor.getCount()>0){

            arrayList = new ArrayList<>();

            while (cursor.moveToNext()){
                int id = cursor.getInt(0);
                double amount = cursor.getDouble(1);
                String reason = cursor.getString(2);
                double time = cursor.getDouble(3);

                hashMap = new HashMap<>();
                hashMap.put("id","" + id);
                hashMap.put("amount","" + amount);
                hashMap.put("reason","" + reason);
                hashMap.put("time","" + time);
                arrayList.add(hashMap);
            }

            listView.setAdapter(new My_Adapter());

        }else {
            tvTitle.setText("\n\n No Data Found");
        }


    }

    public class My_Adapter extends BaseAdapter {

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = getLayoutInflater();
            View myView = inflater.inflate(R.layout.item , parent, false);

            TextView tvreason = myView.findViewById(R.id.tvReason);
            TextView tvAmount = myView.findViewById(R.id.tvAmount);
            TextView tvId = myView.findViewById(R.id.tvID);
            TextView tvTime = myView.findViewById(R.id.tvTime);
            TextView tvDelete = myView.findViewById(R.id.tvDelete);

            hashMap = arrayList.get(position);

            String id = hashMap.get("id");
            String amount = hashMap.get("amount");
            String reason = hashMap.get("reason");
            String time = hashMap.get("time");

            tvreason.setText(reason);
            tvAmount.setText("BTD "+amount);
            tvId.setText(id);
            tvDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (EXPANSE==true) dbHelper.deletebyExpense(id);
                    else dbHelper.deletebyIncome(id);


                    loadData();

                }
            });


            return myView;
        }
    }

}