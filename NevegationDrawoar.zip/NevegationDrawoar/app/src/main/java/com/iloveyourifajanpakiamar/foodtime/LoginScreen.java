package com.iloveyourifajanpakiamar.foodtime;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.google.android.material.textfield.TextInputLayout;

import de.hdodenhof.circleimageview.CircleImageView;

public class LoginScreen extends AppCompatActivity {

    Button phone_login_button;
    LinearLayout layNonet;
    LinearLayout rifa;
    Button retry,forgetpass,login_button,need_new_account;
    TextInputLayout emaillog,password;
    CircleImageView facebook,google;
    ProgressBar progresbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        progresbar = findViewById(R.id.progresbar);
        phone_login_button = findViewById(R.id.phone_login_button);
        forgetpass = findViewById(R.id.forgetpass);
        login_button = findViewById(R.id.login_button);
        need_new_account = findViewById(R.id.need_new_account);
        emaillog = findViewById(R.id.emaillog);
        password = findViewById(R.id.password);
        facebook = findViewById(R.id.facebook);
        google = findViewById(R.id.google);


        rifa = findViewById(R.id.rifa);
        layNonet = findViewById(R.id.layNonet);

        retry =  findViewById(R.id.retry);
        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recreate();
            }
        });




        if(!isNetworkAvailable(LoginScreen.this)){
            rifa.setVisibility(View.GONE);
            layNonet.setVisibility(View.VISIBLE);
        }else{
            rifa.setVisibility(View.VISIBLE);
            layNonet.setVisibility(View.GONE);
        }


        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progresbar.setVisibility(View.VISIBLE);
                login_button.setVisibility(View.INVISIBLE);

                Intent intent = new Intent(LoginScreen.this,MainActivity.class);
                startActivity(intent);
            }
        });



    }


    public static boolean isNetworkAvailable(Context context) {
        return ((ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE))
                .getActiveNetworkInfo() != null;
    }



    //backpressed system-------------------------------------------------------

    @Override
    public void onBackPressed() {


        new AlertDialog.Builder(LoginScreen.this)
                .setTitle("Confirm Exiting")
                .setMessage("Do you want to exit an App")
                .setIcon(R.drawable.logoapp)
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })

                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                        finishAndRemoveTask();
                    }
                })
                .show();

    }
    //-------------------------------------------------------------------------------------


}