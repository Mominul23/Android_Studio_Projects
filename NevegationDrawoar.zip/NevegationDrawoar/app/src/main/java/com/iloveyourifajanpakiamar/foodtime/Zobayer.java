package com.iloveyourifajanpakiamar.foodtime;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

public class Zobayer extends AppCompatActivity {

    private static int SPLASH_SCREEN = 3000;
    ImageView logo;
    TextView app_name,copy,verson;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_zobayer);



        logo = findViewById(R.id.logo);
        app_name= findViewById(R.id.app_name);
        verson = findViewById(R.id.verson);
        copy = findViewById(R.id.copy);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(Zobayer.this, LoginScreen.class);
                startActivity(intent);

            }

        },SPLASH_SCREEN);

    }
}